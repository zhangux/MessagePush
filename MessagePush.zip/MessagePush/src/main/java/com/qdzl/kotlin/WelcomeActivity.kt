package com.qdzl.kotlin

import android.app.Activity
import android.os.Bundle
import com.qdzl.R
import com.qdzl.R.id.dstImageView

/**
 * Created by QDZL on 2018/2/27.
 */
class WelcomeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imgedit);

    }
}